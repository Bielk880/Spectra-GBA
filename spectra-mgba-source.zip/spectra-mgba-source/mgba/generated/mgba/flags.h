#ifndef FLAGS_H
#define FLAGS_H
#define M_CORE_GBA
#define COLOR_16_BIT
#define COLOR_5_6_5
#define ENABLE_VFS
#define ENABLE_VFS_FD
#endif
