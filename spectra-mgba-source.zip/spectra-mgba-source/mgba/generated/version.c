#include <mgba/core/version.h>
MGBA_EXPORT const char* const gitCommit = "spectra";
MGBA_EXPORT const char* const gitCommitShort = "spectra";
MGBA_EXPORT const char* const gitBranch = "master";
MGBA_EXPORT const int gitRevision = 0;
MGBA_EXPORT const char* const binaryName = "spectra";
MGBA_EXPORT const char* const projectName = "mGBA";
MGBA_EXPORT const char* const projectVersion = "0.11-spectra";
