# Código-fonte do mGBA usado no Spectra GBA

O Spectra GBA usa o **mGBA**, de Vicki Pfau e colaboradores, distribuído sob a
**Mozilla Public License 2.0** (texto completo em `LICENSE-MPL-2.0`).

- Projeto original: https://github.com/mgba-emu/mgba
- Site: https://mgba.io

## O que está aqui

A pasta `mgba/` é o código do mGBA (versão 0.11) que o Spectra compila para o
**Modo Link**. Foram mantidos só os arquivos necessários para o Game Boy Advance.

## O que o Spectra mudou

Um único arquivo do mGBA foi alterado: **`mgba/src/gba/sio/lockstep.c`**
(o cabo virtual do Modo Link). Cada mudança está marcada no código com um
comentário que começa com `Spectra:`:

1. Evita repetir o evento do cabo sem o tempo avançar, o que travava os dois jogos.
2. Ao carregar um save state, tira o evento do cabo da fila antes de reagendar,
   para ele não ser agendado duas vezes.
3. Ao carregar um save state, marca o fim da lista de eventos livres.
4. Ao carregar um save state, marca o fim da fila de eventos. Sem isso a fila
   "emendava" na lista livre e parecia cheia, travando ou fechando o Modo Link.

O arquivo `mgba/generated/version.c` foi gerado para o Spectra (identifica a versão).

## Modo normal

No modo normal (um jogo por vez), o Spectra usa o núcleo **mGBA para libretro**
sem modificações, compilado pelo projeto libretro:

- Código-fonte: https://github.com/libretro/mgba

## Outras bibliotecas

- **rcheevos** (conquistas do RetroAchievements), licença MIT: texto em
  `LICENSE-rcheevos-MIT`. Código-fonte: https://github.com/RetroAchievements/rcheevos
